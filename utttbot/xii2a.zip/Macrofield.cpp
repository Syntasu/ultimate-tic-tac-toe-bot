#include "Macrofield.h"

void Macrofield::SetField(int index, string fieldData)
{
    fields[index] = Field(fieldData);
}
